#include <dplyr/main.h>
#include <tools/Quosure.h>
#include <dplyr/registration.h>
#include <dplyr/BoolResult.h>
#include <dplyr/GroupedDataFrame.h>

// avoid inclusion of package header file
#define dplyr_dplyr_H

#!/usr/bin/env Rscript

# Import R Libraries

library(crayon, lib.loc = "/dfs/opt/R_Library")
library(reshape2, lib.loc = "/dfs/opt/R_Library")
library(config, lib.loc = "/dfs/opt/R_Library")
library(sparklyr, lib.loc = "/dfs/opt/R_Library")
library(checkmate, lib.loc = "/dfs/opt/R_Library")
library(bindrcpp, lib.loc = "/dfs/opt/R_Library")
library(dplyr, lib.loc = "/dfs/opt/R_Library")
library(withr, lib.loc = "/dfs/opt/R_Library")
library("a2munge", lib.loc = "/dfs/opt/R_Library")
library("readr", lib.loc = "/dfs/opt/R_Library")
library("openssl", lib.loc = "/dfs/opt/R_Library")
library(jsonlite, lib.loc = "/dfs/opt/R_Library")

# Read Batch ID, Project Name & Config File arguments from passing script

args = commandArgs(trailingOnly=TRUE)

project <- args[2]

conf_file <- args[3]

xdf_root <- args[4]

# Read the config file into a 2 data frames - 1. Spark connection 2. Component Config

conf_json <- jsonlite::fromJSON(
  readLines(conf_file)
)

spark_conn_df <- as.data.frame(conf_json$parameters)

spark_master <- as.character((spark_conn_df[spark_conn_df$name == "spark.master", "value"]))
spark_driver_memory <- as.character((spark_conn_df[spark_conn_df$name == "spark.driver.memory", "value"]))
spark_executor_memory <- as.character((spark_conn_df[spark_conn_df$name == "spark.executor.memory", "value"]))
spark_executor_cores <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.executor.cores", "value"]))
spark_executor_instances <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.executor.instances", "value"]))
spark_cores_max <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.cores.max", "value"]))

# Sparklyr gateway port configuration is required to ensure that 2 processes do not use the same port

sparklyr_gateway_port <- as.character((spark_conn_df[spark_conn_df$name == "sparklyr.gateway.port", "value"]))
spark_memory_fraction <- as.character((spark_conn_df[spark_conn_df$name == "spark.memory.fraction", "value"]))

conf <- spark_config()
conf$spark.driver.memory <- spark_driver_memory
conf$spark.executor.memory <- spark_executor_memory
conf$spark.cores.max <- spark_cores_max
conf$spark.executor.cores <- spark_executor_cores
conf$spark.executor.instances <- spark_executor_instances
conf$spark.memory.fraction <- spark_memory_fraction
conf$sparklyr.log.console <- "TRUE"
conf$sparklyr.gateway.port <- sparklyr_gateway_port
#conf[["sparklyr.shell.deploy-mode"]] <- "client"
conf[["sparklyr.gateway.remote"]] <- "TRUE"

# Set environment variables for Sparklyr operations

Sys.setenv(SPARK_HOME = "/opt/mapr/spark/spark-current")
Sys.setenv(JAVA_HOME = "/usr/lib/jvm/java")
Sys.setenv(HADOOP_HOME = "/opt/mapr/hadoop/hadoop-2.7.0")
Sys.setenv(HADOOP_CONF_DIR = "/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop")

# Set up Spark connection using the config parameters

sc <- spark_connect(master = spark_master, config = conf)

# Read Detecter Component parameter values

detect_conf_df <- as.data.frame(conf_json$detecter)

.index_var <- as.character(detect_conf_df$indexField)
.group_vars <- as.character(detect_conf_df$groupField)
.measure_vars <- as.character(detect_conf_df$measureField)
.fun_var <- as.character(detect_conf_df$functionName)
.frequency <- as.numeric(detect_conf_df$frequency)
.direction <- as.character(detect_conf_df$direction)
.alpha <- as.numeric(detect_conf_df$alpha)
.maxAnoms <- as.numeric(detect_conf_df$maxAnoms)
.trendWindow <- as.numeric(detect_conf_df$trendWindow)

# Group variables is not mandatory parameter for Detecter. Hence, logic
#    is required to handle Null scenario

if(is.na(.group_vars) || .group_vars == "") {
  .summ_group_vars <- .index_var
} else {
  .summ_group_vars <- c(.index_var, .group_vars)
}

# Derive Input & Output Dataset info from MaprDB Metastore

detect_inputs_df <- as.data.frame(conf_json$inputs)

.inp_data_folder <- paste(xdf_root, project, sep = "/")
.inp_catalog <- as.character(detect_inputs_df$catalog)
.inp_dataset_name <- paste(as.character(detect_inputs_df$dataSet), "*.parquet", sep = "/")

detect_outputs_df <- as.data.frame(conf_json$outputs)

.out_data_folder <- paste(xdf_root, project, sep = "/")
.out_catalog <- as.character(detect_outputs_df$catalog)
.out_dataset_name <- as.character(detect_outputs_df$dataSet)

.inp_dataset_folder <- paste(paste(.inp_data_folder, .inp_catalog, sep = "/"), .inp_dataset_name, sep = "/")

.out_dataset_folder <- paste(paste(.out_data_folder, .out_catalog, sep = "/"), .out_dataset_name, sep = "/")

# Create Spark Data frame from Input dataset
# More logic is required to handle different data formats
# Currently, only parquet is supported

.repart_numb <- as.numeric(detect_outputs_df$numberOfFiles)

detect_input_spk_df <- spark_read_parquet(sc, name = "detect_input_spk_df", path = .inp_dataset_folder, repartition = .repart_numb)

# 1. Spark Data frame is not working with Detecter currently. 
#    Hence collect is required to transfer data to R data frame
# 2. More functionality is to be included to handle different
#    date periods based on configuration. Currently, Hourly 
#    is supported

detect_atti_df <- detect_input_spk_df %>%
  select(., .index_var, .measure_vars) %>%
  mutate(., !!.index_var := to_utc_timestamp(concat(
    substring(!!as.name(.index_var), 1, 4), '-',
    substring(!!as.name(.index_var), 6, 2), '-',
    substring(!!as.name(.index_var), 9, 2), ' ',
    substring(!!as.name(.index_var), 12, 2),
    ":00:00"), 'UTC')) %>%
  summariser(.,
             group_vars = .summ_group_vars,
             measure_vars = .measure_vars,
             fun = .fun_var) %>%
  arrange(., desc(!!as.name(.index_var))) %>%
  collect %>%
  detecter(.,
           index_var = .index_var,
           group_vars = if(is.na(.group_vars) || .group_vars == "") {NULL} else {.group_vars},
           measure_vars = paste(.measure_vars, .fun_var, sep = "_"),
           frequency = .frequency,
           direction = .direction,
           alpha = .alpha,
           max_anoms = .maxAnoms,
           trend_window = .trendWindow) %>%
  mutate(., !!.index_var := as.character(!!as.name(.index_var)),
         expected = value - resid)

# Mutation of R data frame Timestamp column to string is required
#    due to a pending Sparklyr issue where Spark data frame is unable 
#    to handle R data frame timestamp columns

detect_atti_spk_df <- copy_to(sc, detect_atti_df, overwrite = TRUE)

# R data frame contents cannot be inserted to parquet format
#    hence conversion to Spark data frame is required
# Also, logic is required to handle different output data formats

spark_write_parquet(detect_atti_spk_df, path = .out_dataset_folder, mode = NULL
        )

spark_disconnect(sc)

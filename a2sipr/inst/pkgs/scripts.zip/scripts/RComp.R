#!/usr/bin/env Rscript

# Import R Libraries

library(jsonlite, lib.loc = "/dfs/opt/R_Library")

# Read Batch ID, Project Name & Config File arguments from passing script

args = commandArgs(trailingOnly=TRUE)

batch_id <- args[1]

project <- args[2]

conf_file <- args[3]

xdf_root <- args[4]

# Read the config file for Component, Spark Connection & Dataset Information

conf_json <- jsonlite::fromJSON(
  readLines(conf_file)
)

# Read R Script Component parameter values
# 1. Dataset Type decides whether Inputs & Output folder info will be 
#     configured in component or script.
# 2. Executable R Script location in Application folder
# 3. R Script parameter file location. Should contain list of 
#     libraries that will be used by the R script. JSONLITE is not
#     required in this list
# 4. Temp Flag decides whether the output objects that will be created
#     by R script are to be created in dout or temp catalog folders

rcomp_conf_df <- as.data.frame(conf_json$r_component)

.dataset_type <- as.character(rcomp_conf_df$datasetType)
.script_location <- as.character(rcomp_conf_df$RScript)
.param_file <- as.character(rcomp_conf_df$paramFile)
.temp_flag <- as.character(rcomp_conf_df$createTemporaryDataset)

# Read the parameter file to get list of libraries & Main 
# library location. Load the required libraries in a for loop

param_json <- jsonlite::fromJSON(
  readLines(.param_file)
)

param_df <- as.data.frame(param_json)

r_libraries <- as.character((param_df[param_df$key == "library_list", "value"]))

r_lib_loc <- as.character((param_df[param_df$key == "library_location", "value"]))

r_libs <- as.list(strsplit(r_libraries, ",")[[1]])

for(lib_name in r_libs)
{
  suppressMessages(library(lib_name, character.only = T, lib.loc =  r_lib_loc))
}

# Get Spark configuration parameters using the main 
# config file & configure spark connection

spark_conn_df <- as.data.frame(conf_json$parameters)

spark_master <- as.character((spark_conn_df[spark_conn_df$name == "spark.master", "value"]))
spark_driver_memory <- as.character((spark_conn_df[spark_conn_df$name == "spark.driver.memory", "value"]))
spark_executor_memory <- as.character((spark_conn_df[spark_conn_df$name == "spark.executor.memory", "value"]))
spark_executor_cores <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.executor.cores", "value"]))
spark_executor_instances <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.executor.instances", "value"]))
spark_cores_max <- as.numeric((spark_conn_df[spark_conn_df$name == "spark.cores.max", "value"]))

# Sparklyr gateway port configuration is required to ensure that 2 processes do not use the same port

sparklyr_gateway_port <- as.character((spark_conn_df[spark_conn_df$name == "sparklyr.gateway.port", "value"]))
spark_memory_fraction <- as.character((spark_conn_df[spark_conn_df$name == "spark.memory.fraction", "value"]))

conf <- spark_config()
conf$spark.driver.memory <- spark_driver_memory
conf$spark.executor.memory <- spark_executor_memory
conf$spark.cores.max <- spark_cores_max
conf$spark.executor.cores <- spark_executor_cores
conf$spark.executor.instances <- spark_executor_instances
conf$spark.memory.fraction <- spark_memory_fraction
conf$sparklyr.log.console <- "TRUE"
conf$sparklyr.gateway.port <- sparklyr_gateway_port
#conf[["sparklyr.shell.deploy-mode"]] <- "client"
conf[["sparklyr.gateway.remote"]] <- "TRUE"

# Set environment variables for Sparklyr operations

Sys.setenv(SPARK_HOME = "/opt/mapr/spark/spark-current")
Sys.setenv(JAVA_HOME = "/usr/lib/jvm/java")
Sys.setenv(HADOOP_HOME = "/opt/mapr/hadoop/hadoop-2.7.0")
Sys.setenv(HADOOP_CONF_DIR = "/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop")

# Set up Spark connection using the config parameters

sc <- spark_connect(master = spark_master, config = conf)

# If Input datasets are to be configured from component, the
# below code will be executed to build the input data folder
# paths. The Input data frames will be created with the name
# as "Input Dataset Name" + "_DF". The expectation is that
# R script has to refer to input data frames with the same
# standard names for the script to work. 

rcomp_inputs_df <- as.data.frame(conf_json$inputs)
  
for(inps in rcomp_inputs_df$name) {
  .inp_data_folder <- paste(xdf_root, project, sep = "/")
  .inp_catalog <- as.character((rcomp_inputs_df[rcomp_inputs_df$name == inps, "catalog"]))
  .inp_dataset_name <- as.character((rcomp_inputs_df[rcomp_inputs_df$name == inps, "dataSet"]))
  
  .inp_dataset_folder <- paste(paste(.inp_data_folder, .inp_catalog, sep = "/"),
                               .inp_dataset_name, sep = "/")
  
  inp_df_name <- paste(inps, "DF", sep = "_")
  
  if(.dataset_type == "component") {
    X <- spark_read_parquet(sc, name = inp_df_name, path = .inp_dataset_folder)
    assign(inp_df_name, X)
  }
}

# If Output datasets are to be configured from component, the
# below code will be executed to build the output data folder
# paths. The expectation is that R script should create the 
# output data frame with the standard as 
#   "Output Dataset Name" + "_DF". 

rcomp_outputs_df <- as.data.frame(conf_json$outputs)

.out_data_folder <- paste(xdf_root, project, sep = "/")
.out_dataset_name <- as.character(rcomp_outputs_df$dataSet)
.out_catalog <- as.character(rcomp_outputs_df$catalog)

.out_dataset_folder <- paste(paste(.out_data_folder, .out_catalog, sep = "/"),
                             .out_dataset_name, sep = "/")

output_df_name <- paste(.out_dataset_name, "DF", sep = "_")

# Read R script from file or inline & execute

if (grepl("\\.R", .script_location)) {
  r_script <- paste(readLines(.script_location), collapse="\n")
} else {
  r_script <- .script_location
}

eval(parse(text = r_script))

# The below output creation code will be executed only if the
# configuration mentions it. Else, the object creation code
# should be included in the R Script itself

if(.dataset_type == "component") {
  spark_write_parquet(eval(parse(text=output_df_name)), path = .out_dataset_folder, mode = NULL)
}

spark_disconnect(sc)
